//
//  main.m
//  nssavepaneltest
//
//  Created by Rolf Bjarne Kvinge on 05/11/2019.
//  Copyright © 2019 Rolf Bjarne Kvinge. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
    return NSApplicationMain(argc, argv);
}
