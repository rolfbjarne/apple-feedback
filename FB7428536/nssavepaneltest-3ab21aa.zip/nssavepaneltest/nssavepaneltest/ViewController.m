//
//  ViewController.m
//  nssavepaneltest
//
//  Created by Rolf Bjarne Kvinge on 05/11/2019.
//  Copyright © 2019 Rolf Bjarne Kvinge. All rights reserved.
//

#import "ViewController.h"

NSSavePanel *panel = NULL;

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // Do any additional setup after loading the view.
    
    panel = [[NSSavePanel alloc] init];
    panel.delegate = self;

    NSButton *button = [NSButton buttonWithTitle:@"a" target:self action:@selector (buttonClick:)];
    [self.view addSubview:button];
}

- (void) buttonClick: (NSObject *) something
{
    [panel runModal];
}

- (void)panel:(NSObject *) sender didChangeToDirectoryURL: (NSURL *) url
{
    NSLog (@"panel: %@ Url: %@ Url.Class: %@", panel, url, [url class]);
    assert ([url isKindOfClass:[NSURL class]]);
}

@end
