//
//  ViewController.h
//  nssavepaneltest
//
//  Created by Rolf Bjarne Kvinge on 05/11/2019.
//  Copyright © 2019 Rolf Bjarne Kvinge. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController<NSOpenSavePanelDelegate>


@end

