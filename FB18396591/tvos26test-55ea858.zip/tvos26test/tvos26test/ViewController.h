//
//  ViewController.h
//  tvos26test
//
//  Created by Rolf Bjarne Kvinge on 26/6/25.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

