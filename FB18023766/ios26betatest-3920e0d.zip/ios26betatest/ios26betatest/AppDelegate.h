//
//  AppDelegate.h
//  ios26betatest
//
//  Created by Rolf Bjarne Kvinge on 13/6/25.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

