//
//  AppDelegate.h
//  iosapitest
//
//  Created by Rolf Bjarne Kvinge on 9/8/24.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

