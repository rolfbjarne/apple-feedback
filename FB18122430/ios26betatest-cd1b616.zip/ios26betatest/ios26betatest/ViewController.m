//
//  ViewController.m
//  ios26betatest
//
//  Created by Rolf Bjarne Kvinge on 13/6/25.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
