// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

#import <UIKit/UIKit.h>

static UIView * __strong capturedSuperview;
static BOOL captureSuperview = YES;

@interface ObservingView : UIView
@end

@implementation ObservingView
- (void)willMoveToSuperview:(UIView *)newSuperview
{
	[super willMoveToSuperview:newSuperview];
	if (newSuperview == nil && captureSuperview) {
		capturedSuperview = self.superview;
		fprintf (stderr, "Captured superview in strong storage: %p\n", (__bridge void *) capturedSuperview);
	}
}
@end

@interface ReproViewController : UIViewController
@end

@implementation ReproViewController
- (void)viewDidLoad
{
	[super viewDidLoad];
	self.view.backgroundColor = UIColor.systemBackgroundColor;
	UILabel *instructions = [[UILabel alloc] init];
	instructions.text = @"Tap Run repro to create and release a temporary parent view.\n\n"
		@"The child saves self.superview in strong ARC storage during willMoveToSuperview:nil.\n\n"
		@"Clearing that strong reference after parent teardown should crash.";
	instructions.numberOfLines = 0;
	instructions.translatesAutoresizingMaskIntoConstraints = NO;
	[self.view addSubview:instructions];

	UIButton *button = [UIButton buttonWithType:UIButtonTypeSystem];
	[button setTitle:@"Run repro" forState:UIControlStateNormal];
	[button addTarget:self action:@selector(runRepro) forControlEvents:UIControlEventTouchUpInside];
	button.translatesAutoresizingMaskIntoConstraints = NO;
	[self.view addSubview:button];
	[NSLayoutConstraint activateConstraints:@[
		[instructions.leadingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.leadingAnchor constant:24],
		[instructions.trailingAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.trailingAnchor constant:-24],
		[instructions.topAnchor constraintEqualToAnchor:self.view.safeAreaLayoutGuide.topAnchor constant:24],
		[button.centerXAnchor constraintEqualToAnchor:self.view.centerXAnchor],
		[button.topAnchor constraintEqualToAnchor:instructions.bottomAnchor constant:24],
	]];

	if ([NSProcessInfo.processInfo.environment[@"SUPERVIEW_AUTORUN"] isEqualToString:@"1"]) {
		dispatch_after (dispatch_time (DISPATCH_TIME_NOW, NSEC_PER_SEC), dispatch_get_main_queue (), ^{
			[self runRepro];
		});
	}
}

- (void)runRepro
{
	fprintf (stderr, "START capture=%d\n", captureSuperview);
	@autoreleasepool {
		__attribute__((objc_precise_lifetime)) UIView *parent = [[UIView alloc] initWithFrame:CGRectMake (0, 0, 100, 100)];
		ObservingView *child = [[ObservingView alloc] initWithFrame:CGRectZero];
		[parent addSubview:child];
		fprintf (stderr, "Leaving parent scope: %p\n", (__bridge void *) parent);
	}

	fprintf (stderr, "Parent teardown returned; saved strong pointer: %p\n", (__bridge void *) capturedSuperview);
	fprintf (stderr, "Clearing saved strong reference using ARC\n");
	capturedSuperview = nil;
	fprintf (stderr, "COMPLETE: no crash\n");
}
@end

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@end

@implementation AppDelegate
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
	captureSuperview = ![NSProcessInfo.processInfo.environment[@"SUPERVIEW_CAPTURE"] isEqualToString:@"0"];
	return YES;
}
@end

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>
@property (nonatomic, strong) UIWindow *window;
@end

@implementation SceneDelegate
- (void)scene:(UIScene *)scene willConnectToSession:(UISceneSession *)session options:(UISceneConnectionOptions *)connectionOptions
{
	self.window = [[UIWindow alloc] initWithWindowScene:(UIWindowScene *)scene];
	self.window.rootViewController = [[ReproViewController alloc] init];
	[self.window makeKeyAndVisible];
}
@end

int main (int argc, char **argv)
{
	@autoreleasepool {
		return UIApplicationMain (argc, argv, nil, NSStringFromClass (AppDelegate.class));
	}
}
